Hi, I hope you like these assets. If your a game developer and need assets you might be interested in my new site,  www.gamedeveloperstudio.com . I'm aiming to create a library 
of high quality  assets but economically accessible  for all game developers, There are even more free ones like this too.

If you like them or use them why not consider visiting or supporting my site, the more support the more assets I can produce.

Thanks 

Robert Brooks

 www.gamedeveloperstudio.com
